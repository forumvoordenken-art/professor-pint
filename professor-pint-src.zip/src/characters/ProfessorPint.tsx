import React, { useMemo } from 'react';
import { useCurrentFrame } from 'remotion';
import { getIdleState } from '../animations/idle';
import { getMouthShape, getTalkingBounce, getTalkingGesture } from '../animations/talking';
import { interpolateEmotions } from '../animations/emotions';
import type { Emotion } from '../animations/emotions';
import type { MouthShape } from '../animations/talking';
import { PintGlass } from '../props/PintGlass';

interface ProfessorPintProps {
  emotion?: Emotion;
  previousEmotion?: Emotion;
  emotionTransitionProgress?: number; // 0-1, default 1 (fully transitioned)
  talking?: boolean;
  scale?: number;
}

const COLORS = {
  skin: '#FDDCB5',
  outline: '#1A1A1A',
  vest: '#2D5016',
  vestDark: '#1F3A0F',
  shirt: '#FFFFFF',
  bowtie: '#D4A012',
  bowtieDark: '#B8890F',
  hair: '#D4D4D4',
  hairDark: '#A0A0A0',
  glassFrame: '#3A3A3A',
  glassLens: 'rgba(200,220,240,0.25)',
  pupil: '#1A1A1A',
  iris: '#4A6741',
  eyeWhite: '#FFFFFF',
  mouth: '#8B2020',
  tongue: '#CC5555',
  blush: '#FFAAAA',
  shineWhite: 'rgba(255,255,255,0.6)',
};

const SW = 3.5; // Standard stroke width

export const ProfessorPint: React.FC<ProfessorPintProps> = ({
  emotion = 'neutral',
  previousEmotion = 'neutral',
  emotionTransitionProgress = 1,
  talking = false,
  scale = 1,
}) => {
  const frame = useCurrentFrame();

  // Get all animation states
  const idle = getIdleState(frame);
  const mouthShape = getMouthShape(frame, talking);
  const talkBounce = getTalkingBounce(frame, talking);
  const talkGesture = getTalkingGesture(frame, talking);

  // Interpolate emotion params
  const emo = useMemo(
    () => interpolateEmotions(previousEmotion, emotion, emotionTransitionProgress),
    [previousEmotion, emotion, emotionTransitionProgress]
  );

  // Combine idle breathing + talk bounce
  const bodyY = idle.breathing.y + talkBounce;

  return (
    <svg
      viewBox="-120 -200 240 360"
      width={240 * scale}
      height={360 * scale}
      style={{ overflow: 'visible' }}
    >
      <g transform={`translate(${idle.sway.x}, ${bodyY}) rotate(${idle.sway.rotation})`}>
        {/* === LEGS === */}
        <Legs frame={frame} />

        {/* === BODY (torso + vest + shirt + bowtie) === */}
        <g transform={`scale(${idle.breathing.scaleX}, 1)`}>
          <Body />
        </g>

        {/* === LEFT ARM (gesture arm) === */}
        <LeftArm gestureRotation={talkGesture} />

        {/* === RIGHT ARM + PINT === */}
        <RightArm beerSway={idle.beerSway} />

        {/* === HEAD === */}
        <g transform={`translate(0, -130) rotate(${emo.headTilt})`}>
          <Head
            emo={emo}
            blink={idle.blink}
            pupil={idle.pupil}
            mouthShape={mouthShape}
            talking={talking}
          />
        </g>
      </g>
    </svg>
  );
};

// ============================================================
// Sub-components (private, not exported)
// ============================================================

const Legs: React.FC<{ frame: number }> = () => {
  return (
    <g>
      {/* Left leg */}
      <line x1={-18} y1={65} x2={-22} y2={130} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
      {/* Right leg */}
      <line x1={18} y1={65} x2={22} y2={130} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
      {/* Shoes */}
      <ellipse cx={-26} cy={132} rx={12} ry={5} fill={COLORS.outline} />
      <ellipse cx={26} cy={132} rx={12} ry={5} fill={COLORS.outline} />
    </g>
  );
};

const Body: React.FC = () => {
  return (
    <g>
      {/* Torso - rounded rectangle */}
      <rect x={-38} y={-50} width={76} height={120} rx={20} ry={20} fill={COLORS.shirt} stroke={COLORS.outline} strokeWidth={SW} />

      {/* Vest */}
      <path
        d="M-35,-45 L-35,55 Q-35,65 -25,65 L-8,65 L-8,-30 Q-8,-45 -20,-45 Z"
        fill={COLORS.vest}
        stroke={COLORS.outline}
        strokeWidth={SW}
      />
      <path
        d="M35,-45 L35,55 Q35,65 25,65 L8,65 L8,-30 Q8,-45 20,-45 Z"
        fill={COLORS.vest}
        stroke={COLORS.outline}
        strokeWidth={SW}
      />

      {/* Vest buttons */}
      <circle cx={0} cy={-10} r={3} fill={COLORS.bowtie} stroke={COLORS.outline} strokeWidth={1.5} />
      <circle cx={0} cy={10} r={3} fill={COLORS.bowtie} stroke={COLORS.outline} strokeWidth={1.5} />
      <circle cx={0} cy={30} r={3} fill={COLORS.bowtie} stroke={COLORS.outline} strokeWidth={1.5} />

      {/* Neck */}
      <rect x={-10} y={-62} width={20} height={18} fill={COLORS.skin} stroke={COLORS.outline} strokeWidth={SW} />

      {/* Bowtie */}
      <g transform="translate(0, -48)">
        <path d="M0,0 L-14,-8 L-14,8 Z" fill={COLORS.bowtie} stroke={COLORS.outline} strokeWidth={2} />
        <path d="M0,0 L14,-8 L14,8 Z" fill={COLORS.bowtie} stroke={COLORS.outline} strokeWidth={2} />
        <circle cx={0} cy={0} r={4} fill={COLORS.bowtieDark} stroke={COLORS.outline} strokeWidth={2} />
      </g>
    </g>
  );
};

const LeftArm: React.FC<{ gestureRotation: number }> = ({ gestureRotation }) => {
  return (
    <g transform={`translate(-40, -30) rotate(${-15 + gestureRotation}, 0, 0)`}>
      {/* Upper arm */}
      <line x1={0} y1={0} x2={-20} y2={40} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
      {/* Lower arm */}
      <g transform="translate(-20, 40)">
        <line x1={0} y1={0} x2={-10} y2={35} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
        {/* Hand */}
        <circle cx={-12} cy={38} r={7} fill={COLORS.skin} stroke={COLORS.outline} strokeWidth={SW} />
      </g>
    </g>
  );
};

const RightArm: React.FC<{ beerSway: { rotation: number; liquidOffset: number } }> = ({ beerSway }) => {
  return (
    <g transform="translate(40, -30) rotate(15, 0, 0)">
      {/* Upper arm */}
      <line x1={0} y1={0} x2={20} y2={35} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
      {/* Lower arm - angled to hold pint */}
      <g transform="translate(20, 35) rotate(-30)">
        <line x1={0} y1={0} x2={5} y2={30} stroke={COLORS.outline} strokeWidth={SW * 2} strokeLinecap="round" />
        {/* Hand holding pint */}
        <g transform={`translate(8, 32) rotate(${beerSway.rotation})`}>
          <circle cx={-3} cy={-2} r={7} fill={COLORS.skin} stroke={COLORS.outline} strokeWidth={SW} />
          <g transform="translate(0, -25)">
            <PintGlass liquidOffset={beerSway.liquidOffset} />
          </g>
        </g>
      </g>
    </g>
  );
};

interface HeadProps {
  emo: {
    eyeScaleY: number;
    eyeOffsetY: number;
    pupilScale: number;
    browLeftY: number;
    browRightY: number;
    browLeftRotation: number;
    browRightRotation: number;
    mouthCurve: number;
    mouthWidth: number;
    mouthOpen: number;
    blushOpacity: number;
    headTilt: number;
  };
  blink: number;
  pupil: { x: number; y: number };
  mouthShape: MouthShape;
  talking: boolean;
}

const Head: React.FC<HeadProps> = ({ emo, blink, pupil, mouthShape, talking }) => {
  return (
    <g>
      {/* Head circle */}
      <circle cx={0} cy={0} r={52} fill={COLORS.skin} stroke={COLORS.outline} strokeWidth={SW} />

      {/* Bald top shine */}
      <ellipse cx={-8} cy={-30} rx={18} ry={10} fill={COLORS.shineWhite} opacity={0.4} />
      <ellipse cx={-5} cy={-35} rx={8} ry={5} fill="white" opacity={0.3} />

      {/* Einstein hair - wild curls on sides and back */}
      <EinsteinHair />

      {/* Glasses */}
      <Glasses />

      {/* Eyes */}
      <g transform={`translate(-18, ${-2 + emo.eyeOffsetY})`}>
        <Eye blink={blink} scaleY={emo.eyeScaleY} pupilScale={emo.pupilScale} pupilX={pupil.x} pupilY={pupil.y} />
      </g>
      <g transform={`translate(18, ${-2 + emo.eyeOffsetY})`}>
        <Eye blink={blink} scaleY={emo.eyeScaleY} pupilScale={emo.pupilScale} pupilX={pupil.x} pupilY={pupil.y} />
      </g>

      {/* Eyebrows */}
      <g transform={`translate(-18, ${-16 + emo.browLeftY}) rotate(${emo.browLeftRotation})`}>
        <rect x={-10} y={0} width={20} height={3.5} rx={1.5} fill={COLORS.hairDark} />
      </g>
      <g transform={`translate(18, ${-16 + emo.browRightY}) rotate(${emo.browRightRotation})`}>
        <rect x={-10} y={0} width={20} height={3.5} rx={1.5} fill={COLORS.hairDark} />
      </g>

      {/* Cheek blush */}
      {emo.blushOpacity > 0.01 && (
        <>
          <ellipse cx={-30} cy={12} rx={8} ry={5} fill={COLORS.blush} opacity={emo.blushOpacity} />
          <ellipse cx={30} cy={12} rx={8} ry={5} fill={COLORS.blush} opacity={emo.blushOpacity} />
        </>
      )}

      {/* Mouth */}
      <Mouth
        mouthShape={mouthShape}
        curve={emo.mouthCurve}
        width={emo.mouthWidth}
        emotionOpen={emo.mouthOpen}
        talking={talking}
      />

      {/* Nose - simple small arc */}
      <path
        d="M-3,8 Q0,14 3,8"
        fill="none"
        stroke={COLORS.outline}
        strokeWidth={2}
        strokeLinecap="round"
      />
    </g>
  );
};

const EinsteinHair: React.FC = () => {
  // Wild white/grey curls on sides and back, bald on top
  return (
    <g>
      {/* Left side curls */}
      <path
        d="M-48,-10 Q-62,-15 -58,-28 Q-54,-38 -62,-32 Q-70,-25 -60,-12 Q-65,0 -55,5 Q-62,10 -54,18 Q-58,25 -50,28"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2.5}
      />
      <path
        d="M-46,-18 Q-56,-25 -52,-35 Q-48,-42 -55,-38"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2}
      />
      {/* Extra left curls */}
      <path
        d="M-50,15 Q-60,12 -57,22 Q-54,30 -48,28"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2}
      />

      {/* Right side curls (mirrored) */}
      <path
        d="M48,-10 Q62,-15 58,-28 Q54,-38 62,-32 Q70,-25 60,-12 Q65,0 55,5 Q62,10 54,18 Q58,25 50,28"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2.5}
      />
      <path
        d="M46,-18 Q56,-25 52,-35 Q48,-42 55,-38"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2}
      />
      <path
        d="M50,15 Q60,12 57,22 Q54,30 48,28"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2}
      />

      {/* Back hair (visible behind head at bottom) */}
      <path
        d="M-35,35 Q-40,42 -32,45 Q-20,48 0,48 Q20,48 32,45 Q40,42 35,35"
        fill={COLORS.hair}
        stroke={COLORS.outline}
        strokeWidth={2.5}
      />
      {/* Small tuft curls at back */}
      <path
        d="M-25,42 Q-28,50 -20,48"
        fill="none"
        stroke={COLORS.outline}
        strokeWidth={1.5}
      />
      <path
        d="M20,42 Q24,50 18,48"
        fill="none"
        stroke={COLORS.outline}
        strokeWidth={1.5}
      />
    </g>
  );
};

const Glasses: React.FC = () => {
  return (
    <g transform="translate(0, -2)">
      {/* Left lens */}
      <circle cx={-18} cy={0} r={15} fill={COLORS.glassLens} stroke={COLORS.glassFrame} strokeWidth={2.5} />
      {/* Right lens */}
      <circle cx={18} cy={0} r={15} fill={COLORS.glassLens} stroke={COLORS.glassFrame} strokeWidth={2.5} />
      {/* Bridge */}
      <path d="M-3,0 Q0,-3 3,0" fill="none" stroke={COLORS.glassFrame} strokeWidth={2.5} />
      {/* Left temple arm */}
      <line x1={-33} y1={-2} x2={-50} y2={-8} stroke={COLORS.glassFrame} strokeWidth={2} />
      {/* Right temple arm */}
      <line x1={33} y1={-2} x2={50} y2={-8} stroke={COLORS.glassFrame} strokeWidth={2} />
      {/* Lens shine */}
      <ellipse cx={-22} cy={-5} rx={4} ry={3} fill="white" opacity={0.15} />
      <ellipse cx={14} cy={-5} rx={4} ry={3} fill="white" opacity={0.15} />
    </g>
  );
};

interface EyeProps {
  blink: number;
  scaleY: number;
  pupilScale: number;
  pupilX: number;
  pupilY: number;
}

const Eye: React.FC<EyeProps> = ({ blink, scaleY, pupilScale, pupilX, pupilY }) => {
  const effectiveScaleY = scaleY * blink;
  return (
    <g transform={`scale(1, ${effectiveScaleY})`}>
      {/* Eye white */}
      <ellipse cx={0} cy={0} rx={9} ry={7} fill={COLORS.eyeWhite} stroke={COLORS.outline} strokeWidth={1.5} />
      {/* Iris */}
      <circle cx={pupilX} cy={pupilY} r={4.5 * pupilScale} fill={COLORS.iris} />
      {/* Pupil */}
      <circle cx={pupilX} cy={pupilY} r={2.5 * pupilScale} fill={COLORS.pupil} />
      {/* Eye shine */}
      <circle cx={pupilX + 1.5} cy={pupilY - 1.5} r={1.5} fill="white" opacity={0.8} />
    </g>
  );
};

interface MouthProps {
  mouthShape: MouthShape;
  curve: number;
  width: number;
  emotionOpen: number;
  talking: boolean;
}

const Mouth: React.FC<MouthProps> = ({ mouthShape, curve, width, emotionOpen, talking }) => {
  // Determine openness: talking mouth shapes override emotion openness
  const talkOpen = talking
    ? [0, 3, 6, 10][mouthShape] // Closed, slight, medium, wide
    : emotionOpen * 10;

  const openAmount = Math.max(talkOpen, emotionOpen * 10);
  const halfWidth = 12 * width;

  if (openAmount < 1) {
    // Closed mouth - just a curved line
    return (
      <path
        d={`M${-halfWidth},25 Q0,${25 + curve} ${halfWidth},25`}
        fill="none"
        stroke={COLORS.outline}
        strokeWidth={2.5}
        strokeLinecap="round"
      />
    );
  }

  // Open mouth
  return (
    <g transform="translate(0, 25)">
      <ellipse
        cx={0}
        cy={0}
        rx={halfWidth}
        ry={openAmount * 0.5 + Math.abs(curve) * 0.2}
        fill={COLORS.mouth}
        stroke={COLORS.outline}
        strokeWidth={2.5}
      />
      {/* Tongue hint for wide open */}
      {openAmount > 6 && (
        <ellipse
          cx={2}
          cy={openAmount * 0.25}
          rx={halfWidth * 0.5}
          ry={openAmount * 0.2}
          fill={COLORS.tongue}
        />
      )}
      {/* Teeth hint for medium+ open */}
      {openAmount > 3 && (
        <rect
          x={-halfWidth * 0.6}
          y={-openAmount * 0.35}
          width={halfWidth * 1.2}
          height={2.5}
          fill="white"
          rx={1}
        />
      )}
    </g>
  );
};

export default ProfessorPint;
