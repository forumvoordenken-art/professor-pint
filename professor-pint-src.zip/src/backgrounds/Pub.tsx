import React from 'react';
import { useCurrentFrame } from 'remotion';
import { sineWave } from '../animations/easing';

interface PubProps {
  boardText?: string;
  width?: number;
  height?: number;
}

const COLORS = {
  wall: '#3D2B1F',
  wallLight: '#4A3628',
  floor: '#5C3A1E',
  floorPlank: '#4E2F15',
  bar: '#6B3A2A',
  barTop: '#8B5A3A',
  barFront: '#5C2E1E',
  shelf: '#4A2A1A',
  bottle1: '#2D5016',
  bottle2: '#8B0000',
  bottle3: '#D4A012',
  bottle4: '#1A3A5C',
  stool: '#3A2010',
  stoolSeat: '#5C3A1E',
  chalkboard: '#2A3A2A',
  chalkboardFrame: '#4A2A1A',
  chalk: '#E8E8D8',
  lamp: '#D4A012',
  lampGlow: 'rgba(212, 160, 18, 0.15)',
  warmLight: 'rgba(255, 200, 100, 0.08)',
};

export const Pub: React.FC<PubProps> = ({
  boardText = '',
  width = 1920,
  height = 1080,
}) => {
  const frame = useCurrentFrame();
  const lampSway1 = sineWave(frame, 0.12) * 2;
  const lampSway2 = sineWave(frame, 0.15, 1) * 1.5;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height}>
      {/* Warm light glow overlay def */}
      <defs>
        <radialGradient id="lamp-glow" cx="50%" cy="0%" r="60%">
          <stop offset="0%" stopColor="rgba(255,200,100,0.25)" />
          <stop offset="100%" stopColor="rgba(255,200,100,0)" />
        </radialGradient>
        <radialGradient id="ambient-glow" cx="50%" cy="30%" r="70%">
          <stop offset="0%" stopColor="rgba(255,180,80,0.1)" />
          <stop offset="100%" stopColor="rgba(0,0,0,0)" />
        </radialGradient>
      </defs>

      {/* === BACK WALL === */}
      <rect x={0} y={0} width={width} height={height * 0.72} fill={COLORS.wall} />
      {/* Wall planks texture */}
      {[0.15, 0.35, 0.55, 0.75].map((ratio, i) => (
        <line
          key={`wp-${i}`}
          x1={0} y1={height * ratio}
          x2={width} y2={height * ratio}
          stroke={COLORS.wallLight}
          strokeWidth={1}
          opacity={0.3}
        />
      ))}

      {/* Ambient warm glow */}
      <rect x={0} y={0} width={width} height={height} fill="url(#ambient-glow)" />

      {/* === SHELVES WITH BOTTLES (background) === */}
      <BottleShelf x={120} y={100} />
      <BottleShelf x={1500} y={100} />

      {/* === CHALKBOARD === */}
      <g transform={`translate(${width / 2 - 200}, 60)`}>
        {/* Frame */}
        <rect x={-10} y={-10} width={420} height={220} rx={3} fill={COLORS.chalkboardFrame} stroke="#1A1A1A" strokeWidth={3} />
        {/* Board */}
        <rect x={0} y={0} width={400} height={200} fill={COLORS.chalkboard} />
        {/* Chalk tray */}
        <rect x={-5} y={200} width={410} height={12} fill={COLORS.chalkboardFrame} stroke="#1A1A1A" strokeWidth={2} />
        {/* Chalk pieces */}
        <rect x={50} y={202} width={25} height={5} rx={2} fill={COLORS.chalk} opacity={0.8} />
        <rect x={120} y={203} width={18} height={4} rx={2} fill="#FFD700" opacity={0.6} />
        {/* Board text */}
        {boardText && (
          <text
            x={200}
            y={110}
            textAnchor="middle"
            fill={COLORS.chalk}
            fontSize={36}
            fontFamily="'Courier New', monospace"
            fontWeight="bold"
            opacity={0.9}
          >
            {boardText}
          </text>
        )}
      </g>

      {/* === WOODEN FLOOR === */}
      <rect x={0} y={height * 0.72} width={width} height={height * 0.28} fill={COLORS.floor} />
      {/* Floor planks */}
      {[0, 240, 480, 720, 960, 1200, 1440, 1680].map((x, i) => (
        <line
          key={`fp-${i}`}
          x1={x}
          y1={height * 0.72}
          x2={x}
          y2={height}
          stroke={COLORS.floorPlank}
          strokeWidth={2}
          opacity={0.4}
        />
      ))}

      {/* === BAR COUNTER (foreground) === */}
      <rect x={0} y={height * 0.58} width={width} height={height * 0.16} fill={COLORS.barFront} stroke="#1A1A1A" strokeWidth={2} />
      {/* Bar top surface */}
      <rect x={0} y={height * 0.56} width={width} height={20} rx={3} fill={COLORS.barTop} stroke="#1A1A1A" strokeWidth={2} />
      {/* Bar surface shine */}
      <rect x={100} y={height * 0.565} width={width - 200} height={6} rx={3} fill="rgba(255,255,255,0.06)" />

      {/* === BAR STOOLS === */}
      <BarStool x={300} y={height * 0.72} />
      <BarStool x={700} y={height * 0.72} />
      <BarStool x={1200} y={height * 0.72} />
      <BarStool x={1600} y={height * 0.72} />

      {/* === HANGING LAMPS === */}
      <HangingLamp x={400} y={0} sway={lampSway1} />
      <HangingLamp x={960} y={0} sway={lampSway2} />
      <HangingLamp x={1520} y={0} sway={lampSway1 * -1} />

      {/* === BEER TAPS on bar === */}
      <BeerTaps x={width / 2} y={height * 0.55} />
    </svg>
  );
};

const BottleShelf: React.FC<{ x: number; y: number }> = ({ x, y }) => {
  const bottleColors = [COLORS.bottle1, COLORS.bottle2, COLORS.bottle3, COLORS.bottle4, COLORS.bottle2, COLORS.bottle1];
  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Shelf planks */}
      <rect x={0} y={80} width={300} height={8} fill={COLORS.shelf} stroke="#1A1A1A" strokeWidth={1.5} />
      <rect x={0} y={180} width={300} height={8} fill={COLORS.shelf} stroke="#1A1A1A" strokeWidth={1.5} />
      {/* Top shelf bottles */}
      {bottleColors.map((color, i) => (
        <g key={`bt-${i}`} transform={`translate(${25 + i * 48}, 20)`}>
          <rect x={-8} y={0} width={16} height={58} rx={3} fill={color} stroke="#1A1A1A" strokeWidth={1.5} opacity={0.85} />
          <rect x={-5} y={-8} width={10} height={10} rx={2} fill={color} stroke="#1A1A1A" strokeWidth={1} opacity={0.85} />
          {/* Label */}
          <rect x={-6} y={18} width={12} height={14} rx={1} fill="rgba(255,255,255,0.15)" />
        </g>
      ))}
      {/* Bottom shelf bottles (fewer) */}
      {bottleColors.slice(0, 4).map((color, i) => (
        <g key={`bb-${i}`} transform={`translate(${40 + i * 60}, 120)`}>
          <rect x={-9} y={0} width={18} height={55} rx={4} fill={color} stroke="#1A1A1A" strokeWidth={1.5} opacity={0.75} />
          <rect x={-5} y={-6} width={10} height={8} rx={2} fill={color} stroke="#1A1A1A" strokeWidth={1} opacity={0.75} />
        </g>
      ))}
    </g>
  );
};

const BarStool: React.FC<{ x: number; y: number }> = ({ x, y }) => {
  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Seat */}
      <ellipse cx={0} cy={0} rx={28} ry={8} fill={COLORS.stoolSeat} stroke="#1A1A1A" strokeWidth={2} />
      {/* Legs */}
      <line x1={-18} y1={8} x2={-22} y2={75} stroke={COLORS.stool} strokeWidth={4} strokeLinecap="round" />
      <line x1={18} y1={8} x2={22} y2={75} stroke={COLORS.stool} strokeWidth={4} strokeLinecap="round" />
      <line x1={0} y1={8} x2={0} y2={78} stroke={COLORS.stool} strokeWidth={4} strokeLinecap="round" />
      {/* Foot rest ring */}
      <ellipse cx={0} cy={55} rx={15} ry={4} fill="none" stroke={COLORS.stool} strokeWidth={3} />
    </g>
  );
};

const HangingLamp: React.FC<{ x: number; y: number; sway: number }> = ({ x, y, sway }) => {
  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Chain/wire */}
      <line x1={0} y1={0} x2={sway} y2={100} stroke="#3A3A3A" strokeWidth={2} />
      <g transform={`translate(${sway}, 100)`}>
        {/* Lamp shade */}
        <path
          d="M-25,0 L-18,-20 L18,-20 L25,0 Z"
          fill={COLORS.lamp}
          stroke="#1A1A1A"
          strokeWidth={2}
          opacity={0.9}
        />
        {/* Bulb glow */}
        <circle cx={0} cy={5} r={40} fill={COLORS.lampGlow} />
        <circle cx={0} cy={-5} r={6} fill="#FFF4D6" opacity={0.8} />
      </g>
    </g>
  );
};

const BeerTaps: React.FC<{ x: number; y: number }> = ({ x, y }) => {
  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Base */}
      <rect x={-60} y={-8} width={120} height={10} rx={3} fill="#3A2010" stroke="#1A1A1A" strokeWidth={2} />
      {/* Taps */}
      {[-35, 0, 35].map((tx, i) => (
        <g key={`tap-${i}`} transform={`translate(${tx}, -8)`}>
          <rect x={-4} y={-35} width={8} height={30} rx={2} fill="#C0C0C0" stroke="#1A1A1A" strokeWidth={1.5} />
          <circle cx={0} cy={-38} r={6} fill={['#2D5016', '#8B0000', '#D4A012'][i]} stroke="#1A1A1A" strokeWidth={1.5} />
        </g>
      ))}
    </g>
  );
};

export default Pub;
