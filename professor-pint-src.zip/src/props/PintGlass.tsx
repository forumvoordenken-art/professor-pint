import React from 'react';

interface PintGlassProps {
  liquidOffset?: number;
}

export const PintGlass: React.FC<PintGlassProps> = ({ liquidOffset = 0 }) => {
  return (
    <g>
      {/* Glass body */}
      <path
        d="M-12,0 L-10,-45 Q-10,-48 -7,-48 L7,-48 Q10,-48 10,-45 L12,0 Q12,3 9,3 L-9,3 Q-12,3 -12,0 Z"
        fill="rgba(255,255,255,0.25)"
        stroke="#1A1A1A"
        strokeWidth={2.5}
      />
      {/* Beer liquid */}
      <clipPath id="glass-clip">
        <path d="M-11,-1 L-9.5,-42 L9.5,-42 L11,-1 Z" />
      </clipPath>
      <g clipPath="url(#glass-clip)">
        {/* Beer body - golden amber */}
        <rect
          x={-11}
          y={-38 + liquidOffset}
          width={22}
          height={40}
          fill="#D4A012"
          opacity={0.85}
        />
        {/* Foam top */}
        <ellipse
          cx={0}
          cy={-38 + liquidOffset}
          rx={10}
          ry={3}
          fill="#FFF8E7"
          opacity={0.9}
        />
        <ellipse
          cx={-3}
          cy={-39 + liquidOffset}
          rx={4}
          ry={2}
          fill="white"
          opacity={0.5}
        />
      </g>
      {/* Glass highlight */}
      <line
        x1={-7}
        y1={-42}
        x2={-5}
        y2={-3}
        stroke="white"
        strokeWidth={1.5}
        opacity={0.3}
      />
      {/* Handle */}
      <path
        d="M12,-30 Q22,-30 22,-15 Q22,0 12,0"
        fill="none"
        stroke="#1A1A1A"
        strokeWidth={2.5}
      />
      <path
        d="M12,-28 Q20,-28 20,-15 Q20,-2 12,-2"
        fill="rgba(255,255,255,0.15)"
        stroke="none"
      />
    </g>
  );
};
